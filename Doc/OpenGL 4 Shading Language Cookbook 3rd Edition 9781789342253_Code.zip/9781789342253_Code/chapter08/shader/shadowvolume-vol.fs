#version 410

void main() {
    // Nothing to see here, move along
}
